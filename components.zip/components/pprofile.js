// import React from 'react'
// import student from "../images/student.png"

// export default function Profile() {
//   return (
//     <>
// 		<div class="big_wrap">
// 			<div class="wrap">
// 				<div class="main_wrap">
// 					<fieldset class="sect_head">
// 						<a href="*"><svg width="9" height="18" viewBox="0 0 9 18" fill="none" xmlns="http://www.w3.org/2000/svg">
// 							<path d="M8.00009 16.9201L1.48009 10.4001C0.710088 9.63008 0.710088 8.37008 1.48009 7.60008L8.00009 1.08008" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
// 							</svg>
// 						</a>
// 						<h1>Enter your details</h1>
// 					</fieldset>
//                     <fieldset class="sect_img">
//                         <img src={student} alt="student"/>
//                         <h2>Change profile picture</h2> 
//                     </fieldset>
// 					<fieldset class="sect_form">
// 						<form>
// 							<label for="new_username">
// 								<input id="new_username" type="text" placeholder="new username" required/><br/>
// 								this user name is already taken
// 							</label><br/>
// 							<label for="bio">
// 								<input id="bio" type="textarea" placeholder="Bio" required/><br/>
								
// 							</label>
// 						</form>
// 					</fieldset>
// 					<fieldset class="ProfileFooter">
// 						<a href="" class="cancelbtn"><button>Cancel</button></a>
// 						<a href="" class="savebtn"><button>Save</button></a>
// 					</fieldset>
// 				</div>
// 			</div>
// 		</div>
//     </>
//   )
// }
