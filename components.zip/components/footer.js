// import { Container } from "react-bootstrap";
// import {AiFillHome, AiFillHeart} from 'react-icons/ai'
// import { BsFillPersonFill, BsPlayFill} from 'react-icons/bs'

// export default function Footer () {
//     return(
//         <>
//           <section className={styles.sect41}>
//         <div className={styles.sect42}>
//           <div className={styles.sect43}>
//           <div id={styles.home}><AiFillHome/></div>
//           <div className={styles.fill}><BsPlayFill/></div>
//           <div className={styles.fill}><AiFillHeart/></div>
//           <div className={styles.fill}><BsFillPersonFill/></div>

//           </div>
//         </div>
//       </section>
//         </>
//     )
// }