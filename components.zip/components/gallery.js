// import React from 'react'
// import google from "../images/google.png"
// import facebook from '../images/facebook.png'

// export default function Gallery() {
//   return (
//     <>
// 		<div class="galleryBig">
// 			<div class="galleryMiddle">
// 				<div class="galleryMain">
// 					<fieldset class="galleryFieldHead">
// 						<h2>Sort by</h2>
// 						<label>
// 							<input type="checkbox" id="sort" name="sort"/> Free classes
// 						</label>
// 						<label>
// 							<input type="checkbox" id="sort" name="sort"/> Premium classes
// 						</label>
// 						<label>
// 							<input type="checkbox" id="sort" name="sort"/> All
// 						</label> 
// 					</fieldset>
// 					<fieldset class="galleryFieldContent">
// 						<h2>Level</h2>
// 						<label>
// 							<input type="checkbox" id="level" name="level"/> Beginner
// 						</label>
// 						<label>
// 							<input type="checkbox" id="level" name="level"/> Intermediate
// 						</label>
// 						<label>
// 							<input type="checkbox" id="level" name="level"/> Advance
// 						</label>
// 					</fieldset>
// 					<fieldset class="galleryFieldContent2">
// 						<h2>Duration</h2>
// 						<label>
// 							<input type="checkbox" id="duration" name="duration"/> 0-1 Hour
// 						</label>
// 						<label>
// 							<input type="checkbox" id="duration" name="duration"/> 1-3 Hour
// 						</label>
// 						<label>
// 							<input type="checkbox" id="duration" name="duration"/> 3+ Hour
// 						</label>
// 					</fieldset>
// 					<fieldset class="galleryFieldBtn">
// 						<a href=""><button class="GallBBtn">Reject</button></a>
// 						<a href=""><button class="GallApp">Apply</button></a>
// 					</fieldset>
// 				</div>
// 			</div>
// 		</div>
// 	</>
// 	)
// }